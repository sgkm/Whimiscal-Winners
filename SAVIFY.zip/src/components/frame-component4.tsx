import { FunctionComponent, useMemo, type CSSProperties } from "react";

export type FrameComponent4Type = {
  eNTERINCOMEINR?: string;
  frame1Placeholder?: string;

  /** Style props */
  propAlignSelf?: CSSProperties["alignSelf"];
  propDisplay?: CSSProperties["display"];
  propMinWidth?: CSSProperties["minWidth"];
};

const FrameComponent4: FunctionComponent<FrameComponent4Type> = ({
  eNTERINCOMEINR,
  frame1Placeholder,
  propAlignSelf,
  propDisplay,
  propMinWidth,
}) => {
  const frameDivStyle: CSSProperties = useMemo(() => {
    return {
      alignSelf: propAlignSelf,
    };
  }, [propAlignSelf]);

  const eNTERINCOMEINRStyle: CSSProperties = useMemo(() => {
    return {
      display: propDisplay,
      minWidth: propMinWidth,
    };
  }, [propDisplay, propMinWidth]);

  return (
    <div className="self-stretch flex flex-col items-start justify-start gap-[3px] text-left text-mini text-darkslategray-100 font-subtitle">
      <div
        className="flex flex-row items-start justify-start py-0 px-9"
        style={frameDivStyle}
      >
        <div
          className="relative capitalize font-medium z-[1]"
          style={eNTERINCOMEINRStyle}
        >
          {eNTERINCOMEINR}
        </div>
      </div>
      <input
        className="w-full [border:none] [outline:none] bg-light-green self-stretch h-[41px] rounded-lg flex flex-row items-start justify-start pt-2 px-[53px] pb-[9px] box-border font-subtitle font-medium text-base text-darkslategray-200 min-w-[214px] z-[1]"
        placeholder={frame1Placeholder}
        type="text"
      />
    </div>
  );
};

export default FrameComponent4;
