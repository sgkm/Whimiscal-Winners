import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const FrameComponent2: FunctionComponent = () => {
  const navigate = useNavigate();

  const onLogInTextClick = useCallback(() => {
    navigate("/home");
  }, [navigate]);

  return (
    <section className="w-[325px] flex flex-row items-start justify-start pt-0 px-[78px] pb-[77px] box-border max-w-full text-center text-xl text-letters-and-icons font-subtitle">
      <div className="flex-1 flex flex-col items-start justify-start gap-[19px]">
        <div className="self-stretch flex flex-row items-start justify-start relative z-[1]">
          <div className="h-9 flex-1 relative">
            <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-11xl bg-main-green" />
          </div>
          <h3
            className="!m-[0] w-[220px] absolute top-[5.8px] left-[-26px] text-inherit leading-[22px] capitalize font-semibold font-inherit flex items-center justify-center cursor-pointer z-[1]"
            onClick={onLogInTextClick}
          >
            Accept
          </h3>
        </div>
        <div className="self-stretch flex flex-row items-start justify-start relative z-[1] text-dark-mode-green-bar">
          <div className="h-9 flex-1 relative">
            <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-11xl bg-light-green" />
          </div>
          <h3 className="!m-[0] w-52 absolute top-[5.8px] left-[-20px] text-inherit leading-[22px] capitalize font-semibold font-inherit flex items-center justify-center z-[1]">
            Send again
          </h3>
        </div>
      </div>
    </section>
  );
};

export default FrameComponent2;
