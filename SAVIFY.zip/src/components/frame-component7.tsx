import { FunctionComponent } from "react";
import FrameComponent3 from "./frame-component3";
import Expense from "./expense";

const FrameComponent7: FunctionComponent = () => {
  return (
    <section className="absolute top-[62px] left-[19px] w-[362px] flex flex-col items-end justify-start gap-[26px] max-w-full text-left text-xl text-letters-and-icons font-subtitle">
      <div className="w-[346px] flex flex-row items-start justify-end py-0 px-[3px] box-border max-w-full">
        <div className="flex-1 flex flex-row items-start justify-between max-w-full gap-[20px]">
          <div className="flex flex-col items-start justify-start pt-[7px] pb-0 pr-4 pl-0">
            <img
              className="w-[19px] h-4 relative"
              loading="lazy"
              alt=""
              src="/bring-back.svg"
            />
          </div>
          <div className="w-[125px] flex flex-col items-start justify-start pt-0.5 px-0 pb-0 box-border">
            <div className="self-stretch relative leading-[22px] capitalize font-semibold">
              RECEIVED
            </div>
          </div>
          <img
            className="h-[30px] w-[30px] relative rounded-[25.71px] overflow-hidden shrink-0"
            loading="lazy"
            alt=""
            src="/iconnotification.svg"
          />
        </div>
      </div>
      <div className="self-stretch flex flex-col items-end justify-start gap-[17px] max-w-full text-mini text-white">
        <FrameComponent3 />
        <div className="self-stretch flex flex-row items-start justify-end py-0 pr-1 pl-0 box-border max-w-full">
          <div className="flex-1 flex flex-row items-start justify-start gap-[16px] max-w-full">
            <div className="flex-1 flex flex-col items-start justify-start pt-4 px-[38px] pb-[13px] relative gap-[1.5px]">
              <div className="w-full h-full absolute !m-[0] top-[0px] right-[0px] bottom-[0px] left-[0px] rounded-[14.89px] bg-ocean-blue-button" />
              <input className="m-0 self-stretch h-[25px]" type="checkbox" />
              <div className="self-stretch h-[22px] flex flex-row items-start justify-start py-0 pr-7 pl-[19px] box-border">
                <div className="flex-1 relative capitalize font-medium whitespace-pre-wrap z-[1]">
                  {" "}
                  SENT
                </div>
              </div>
              <div className="relative text-xl leading-[22px] capitalize font-semibold inline-block min-w-[95px] whitespace-nowrap z-[1]">
                $4,120.00
              </div>
            </div>
            <Expense
              arrow1="/arrow-12.svg"
              propBackgroundColor="#fff"
              propBorder="2.1px solid #000"
              propColor="#000"
              propColor1="#000"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default FrameComponent7;
