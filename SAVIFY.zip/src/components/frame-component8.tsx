import { FunctionComponent } from "react";
import FrameComponent4 from "./frame-component4";

const FrameComponent8: FunctionComponent = () => {
  return (
    <section className="self-stretch flex flex-row items-start justify-start py-0 pr-0 pl-[19px] box-border relative max-w-full text-left text-mini text-darkslategray-100 font-subtitle">
      <div className="h-[41px] w-[357px] absolute !m-[0] bottom-[-37px] left-[19px] rounded-lg bg-light-green z-[1]" />
      <div className="flex-1 flex flex-row items-start justify-end pt-0 pb-[7px] pr-[17px] pl-0 box-border max-w-full">
        <div className="flex-1 flex flex-col items-start justify-start gap-[16px] max-w-full">
          <FrameComponent4
            eNTERINCOMEINR="ENTER INCOME (INR)"
            frame1Placeholder="00.00"
          />
          <div className="flex flex-row items-start justify-start py-0 px-9">
            <div className="relative capitalize font-medium z-[1]">
              ENTER NO. OF PROPERTY OWNED
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FrameComponent8;
