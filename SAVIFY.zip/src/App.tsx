import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import Analytics from "./pages/analytics";
import AOnBoarding from "./pages/a-on-boarding";
import BOnBoarding from "./pages/b-on-boarding";
import ACategories from "./pages/a-categories";
import ASecurityPin from "./pages/a-security-pin";
import Home from "./pages/home";
import CSent from "./pages/c-sent";
import CTransactionIncome from "./pages/c-transaction-income";
import LoanPrediction from "./pages/loan-prediction";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/2-a-on-boarding":
        title = "";
        metaDescription = "";
        break;
      case "/2-b-on-boarding":
        title = "";
        metaDescription = "";
        break;
      case "/940-a-categories":
        title = "";
        metaDescription = "";
        break;
      case "/security-pin":
        title = "";
        metaDescription = "";
        break;
      case "/home":
        title = "";
        metaDescription = "";
        break;
      case "/sent":
        title = "";
        metaDescription = "";
        break;
      case "/received":
        title = "";
        metaDescription = "";
        break;
      case "/loan-prediction":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag: HTMLMetaElement | null = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<Analytics />} />
      <Route path="/2-a-on-boarding" element={<AOnBoarding />} />
      <Route path="/2-b-on-boarding" element={<BOnBoarding />} />
      <Route path="/940-a-categories" element={<ACategories />} />
      <Route path="/security-pin" element={<ASecurityPin />} />
      <Route path="/home" element={<Home />} />
      <Route path="/sent" element={<CSent />} />
      <Route path="/received" element={<CTransactionIncome />} />
      <Route path="/loan-prediction" element={<LoanPrediction />} />
    </Routes>
  );
}
export default App;
