import { FunctionComponent, useMemo, type CSSProperties } from "react";

export type ExpenseType = {
  arrow1?: string;

  /** Style props */
  propBackgroundColor?: CSSProperties["backgroundColor"];
  propBorder?: CSSProperties["border"];
  propColor?: CSSProperties["color"];
  propColor1?: CSSProperties["color"];
};

const Expense: FunctionComponent<ExpenseType> = ({
  arrow1,
  propBackgroundColor,
  propBorder,
  propColor,
  propColor1,
}) => {
  const rectangleDivStyle: CSSProperties = useMemo(() => {
    return {
      backgroundColor: propBackgroundColor,
    };
  }, [propBackgroundColor]);

  const rectangleDiv1Style: CSSProperties = useMemo(() => {
    return {
      border: propBorder,
    };
  }, [propBorder]);

  const sENTStyle: CSSProperties = useMemo(() => {
    return {
      color: propColor,
    };
  }, [propColor]);

  const divStyle: CSSProperties = useMemo(() => {
    return {
      color: propColor1,
    };
  }, [propColor1]);

  return (
    <div className="flex-[0.9368] flex flex-col items-start justify-start pt-[15px] px-[41px] pb-3 relative gap-[2px] text-left text-mini text-honeydew font-subtitle">
      <div
        className="w-full h-full absolute !m-[0] top-[0px] right-[0px] bottom-[0px] left-[0px] rounded-[14.89px] bg-ocean-blue-button"
        style={rectangleDivStyle}
      />
      <div className="self-stretch flex flex-row items-start justify-start py-0 px-8">
        <div className="h-[25px] w-[25px] relative z-[1]">
          <div
            className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-[6.25px] box-border border-[2.1px] border-solid border-honeydew"
            style={rectangleDiv1Style}
          />
          <img
            className="absolute h-3/6 w-6/12 top-[25.2%] right-[24.8%] bottom-[24.8%] left-[25.2%] max-w-full overflow-hidden max-h-full object-contain z-[1]"
            alt=""
            src={arrow1}
          />
        </div>
      </div>
      <div className="flex flex-row items-start justify-start py-0 pr-1.5 pl-[13px]">
        <div
          className="relative capitalize font-medium inline-block min-w-[70px] z-[1]"
          style={sENTStyle}
        >
          RECEIVED
        </div>
      </div>
      <div
        className="relative text-xl leading-[22px] capitalize font-semibold inline-block min-w-[88px] whitespace-nowrap z-[1]"
        style={divStyle}
      >
        $1.187.40
      </div>
    </div>
  );
};

export default Expense;
