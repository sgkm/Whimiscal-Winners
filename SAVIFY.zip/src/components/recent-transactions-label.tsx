import { FunctionComponent } from "react";

const RecentTransactionsLabel: FunctionComponent = () => {
  return (
    <section className="self-stretch flex-1 flex flex-col items-end justify-start gap-[30px] text-left text-lg text-black font-inria-sans">
      <div className="self-stretch flex-1 flex flex-row items-end justify-start gap-[15px]">
        <div className="h-[50px] w-[50px] relative rounded-31xl shrink-0 flex items-center justify-center">
          <img
            className="h-full w-full overflow-hidden shrink-0 object-contain absolute left-[0px] top-[0px] [transform:scale(1.48)]"
            loading="lazy"
            alt=""
            src="/arrowleftdownline.svg"
          />
        </div>
        <div className="flex flex-col items-start justify-end pt-0 px-0 pb-1">
          <div className="flex flex-col items-start justify-start gap-[4px]">
            <h3 className="m-0 relative text-inherit font-bold font-inherit inline-block min-w-[76px]">
              From ABC
            </h3>
            <div className="relative text-xs text-darkgray-200 inline-block min-w-[125px] whitespace-nowrap">
              20 Jan 2024 at 10:00 PM
            </div>
          </div>
        </div>
      </div>
      <div className="self-stretch flex-1 flex flex-row items-start justify-start py-0 pr-0 pl-px gap-[14px]">
        <div className="h-[50px] w-[50px] relative rounded-31xl shrink-0 flex items-center justify-center">
          <img
            className="h-full w-full overflow-hidden shrink-0 object-contain absolute left-[0px] top-[0px] [transform:scale(1.48)]"
            loading="lazy"
            alt=""
            src="/arrowrightupline1.svg"
          />
        </div>
        <div className="flex flex-col items-start justify-start pt-[5px] px-0 pb-0">
          <div className="flex flex-col items-start justify-start gap-[3px]">
            <h3 className="m-0 relative text-inherit font-bold font-inherit inline-block min-w-[51px]">
              To XYZ
            </h3>
            <div className="relative text-xs text-darkgray-200 inline-block min-w-[125px] whitespace-nowrap">
              20 Jan 2024 at 10:00 PM
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default RecentTransactionsLabel;
