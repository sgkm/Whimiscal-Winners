import { FunctionComponent, useCallback } from "react";
import FrameComponent7 from "../components/frame-component7";
import { useNavigate } from "react-router-dom";

const CTransactionIncome: FunctionComponent = () => {
  const navigate = useNavigate();

  const onHome3LineIconClick = useCallback(() => {
    navigate("/home");
  }, [navigate]);

  return (
    <div className="w-full h-[852px] relative rounded-21xl bg-main-green overflow-hidden leading-[normal] tracking-[normal] text-left text-mini text-ocean-blue-button font-subtitle">
      <div className="absolute top-[849px] left-[calc(50%_-_214.5px)] w-[430px] h-[599px] flex items-center justify-center">
        <img
          className="w-full h-full object-contain absolute left-[0px] top-[217px] [transform:scale(6.167)]"
          alt=""
          src="/rectangle-1481.svg"
        />
      </div>
      <div className="absolute top-[769px] left-[calc(50%_+_110.5px)] capitalize font-medium text-right hidden min-w-[69px]">
        -$674,40
      </div>
      <div className="absolute top-[775.4px] left-[calc(50%_-_103.5px)] text-xs capitalize font-semibold hidden min-w-[96px] whitespace-nowrap">
        18:39 - March 31
      </div>
      <div className="absolute top-[773px] left-[calc(50%_+_38.5px)] text-smi leading-[15px] font-light text-gray-400 hidden min-w-[29px]">
        Rent
      </div>
      <section className="absolute top-[362px] left-[16px] w-[360px] flex flex-col items-start justify-start gap-[15px] max-w-full text-left text-mini text-gray-400 font-subtitle">
        <div className="flex flex-row items-start justify-start pt-0 px-[3px] pb-[5px] text-letters-and-icons">
          <div className="relative capitalize font-medium inline-block min-w-[35px] z-[1]">
            April
          </div>
        </div>
        <div className="self-stretch flex flex-row items-start justify-start gap-[37px]">
          <div className="flex-1 flex flex-col items-start justify-start gap-[20px]">
            <div className="self-stretch flex flex-row items-start justify-start gap-[20px]">
              <button className="cursor-pointer [border:none] p-0 bg-[transparent] h-[53px] w-[57px] relative z-[1]">
                <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-3xl bg-blue-button" />
                <img
                  className="absolute h-[51.7%] w-[29.47%] top-[24.53%] right-[35.44%] bottom-[23.77%] left-[35.09%] max-w-full overflow-hidden max-h-full z-[1]"
                  alt=""
                  src="/transport-instance.svg"
                />
              </button>
              <div className="flex flex-col items-start justify-start py-0 pr-[15.5px] pl-0 gap-[2.4px]">
                <div className="relative capitalize font-medium inline-block min-w-[73px] z-[1]">
                  Groceries
                </div>
                <div className="relative text-xs capitalize font-semibold text-ocean-blue-button inline-block min-w-[89px] whitespace-nowrap z-[1]">
                  17:00 - April 24
                </div>
              </div>
              <div className="flex flex-col items-start justify-start pt-[8.1px] px-0 pb-0 text-smi">
                <div className="h-[35.5px] flex flex-row items-end justify-start gap-[10.5px]">
                  <div className="h-[36.5px] w-px relative box-border z-[1] border-r-[1px] border-solid border-main-green" />
                  <div className="flex flex-col items-start justify-end pt-0 px-0 pb-[3.6px]">
                    <div className="relative leading-[15px] font-light inline-block min-w-[41px] z-[1]">
                      Pantry
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="self-stretch flex flex-row items-start justify-start py-0 pr-1.5 pl-px">
              <div className="flex-1 flex flex-row items-start justify-start gap-[17px]">
                <div className="w-[59px] flex flex-col items-start justify-start gap-[23.5px] text-letters-and-icons">
                  <img
                    className="w-[57px] h-[53px] relative z-[1]"
                    loading="lazy"
                    alt=""
                    src="/icon-rent.svg"
                  />
                  <div className="self-stretch flex flex-row items-start justify-start py-0 pr-0 pl-0.5">
                    <button className="cursor-pointer [border:none] p-0 bg-[transparent] h-[53px] flex-1 relative z-[1]">
                      <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-3xl bg-blue-button" />
                      <img
                        className="absolute h-[48.11%] w-[44.74%] top-[26.42%] right-[27.19%] bottom-[25.47%] left-[28.07%] max-w-full overflow-hidden max-h-full z-[1]"
                        alt=""
                        src="/vector-13.svg"
                      />
                    </button>
                  </div>
                  <div className="flex flex-row items-start justify-start py-0 pr-[7px] pl-1">
                    <div className="relative capitalize font-medium inline-block min-w-[48px] z-[1]">
                      March
                    </div>
                  </div>
                </div>
                <div className="flex-1 flex flex-col items-start justify-start pt-[5px] pb-0 pr-[22.5px] pl-0">
                  <div className="self-stretch flex flex-col items-start justify-start gap-[29.6px]">
                    <div className="flex flex-col items-start justify-start gap-[2.4px]">
                      <div className="relative capitalize font-medium inline-block min-w-[35px] z-[1]">
                        Rent
                      </div>
                      <div className="relative text-xs capitalize font-semibold text-ocean-blue-button inline-block min-w-[82px] z-[1]">
                        8:30 - April 15
                      </div>
                    </div>
                    <div className="flex flex-row items-start justify-start py-0 pr-0 pl-px">
                      <div className="flex flex-col items-start justify-start gap-[2.4px]">
                        <div className="relative capitalize font-medium inline-block min-w-[74px] z-[1]">
                          Transport
                        </div>
                        <div className="relative text-xs capitalize font-semibold text-ocean-blue-button inline-block min-w-[84px] z-[1]">
                          7:30 - April 08
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="w-[46.5px] flex flex-col items-start justify-start pt-[13.1px] px-0 pb-0 box-border text-smi">
                  <div className="self-stretch flex flex-row items-end justify-start gap-[15.5px]">
                    <div className="flex flex-row items-start justify-start">
                      <div className="h-[36.5px] w-px relative box-border z-[1] border-r-[1px] border-solid border-main-green" />
                      <div className="flex flex-col items-start justify-start pt-[73px] px-0 pb-0">
                        <div className="w-px h-[36.5px] relative box-border z-[1] border-r-[1px] border-solid border-main-green" />
                      </div>
                    </div>
                    <div className="flex-1 flex flex-col items-start justify-end pt-0 px-0 pb-[11.6px]">
                      <div className="self-stretch flex flex-col items-start justify-start gap-[55px]">
                        <div className="relative leading-[15px] font-light inline-block min-w-[29px] z-[1]">
                          Rent
                        </div>
                        <div className="flex flex-row items-start justify-start py-0 pr-0.5 pl-px">
                          <div className="relative leading-[15px] font-light inline-block min-w-[26px] z-[1]">
                            Fuel
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="w-[69px] flex flex-col items-start justify-start pt-[8.1px] px-0 pb-0 box-border text-right text-ocean-blue-button">
            <div className="self-stretch flex flex-col items-end justify-start gap-[42.1px]">
              <div className="self-stretch flex flex-row items-end justify-start py-0 pr-0 pl-[3px]">
                <div className="relative capitalize font-medium inline-block min-w-[66px] z-[1]">
                  -$100,00
                </div>
                <div className="h-[36.5px] w-px relative box-border z-[2] ml-[-65.1px] border-r-[1px] border-solid border-main-green" />
              </div>
              <div className="self-stretch flex flex-col items-end justify-start gap-[37.5px]">
                <div className="self-stretch h-[35.5px] flex flex-row items-end justify-start">
                  <div className="flex flex-col items-start justify-end pt-0 px-0 pb-[4.6px]">
                    <div className="relative capitalize font-medium inline-block min-w-[69px] z-[1]">
                      -$674,40
                    </div>
                  </div>
                  <div className="h-[36.5px] w-px relative box-border z-[2] ml-[-65.1px] border-r-[1px] border-solid border-main-green" />
                </div>
                <div className="h-[35.5px] flex flex-row items-start justify-start py-0 pr-0 pl-[5px] box-border gap-[17.1px]">
                  <div className="h-[36.5px] w-px relative box-border z-[1] border-r-[1px] border-solid border-main-green" />
                  <div className="flex flex-col items-start justify-start pt-[4.9px] px-0 pb-0">
                    <div className="relative capitalize font-medium inline-block min-w-[46px] z-[1]">
                      -$4,13
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="self-stretch flex flex-row items-start justify-start py-0 pr-0 pl-[3px] box-border max-w-full">
          <div className="flex-1 flex flex-col items-start justify-start gap-[24px] max-w-full">
            <div className="self-stretch flex flex-row items-start justify-start py-0 pr-0 pl-px box-border max-w-full">
              <div className="flex-1 flex flex-row items-end justify-start gap-[28.5px] max-w-full">
                <div className="flex-1 flex flex-row items-start justify-start gap-[16px]">
                  <button className="cursor-pointer [border:none] p-0 bg-[transparent] h-[53px] w-[57px] relative z-[1]">
                    <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-3xl bg-light-blue-button" />
                    <img
                      className="absolute h-[52.45%] w-[27.37%] top-[24.53%] right-[35.79%] bottom-[23.02%] left-[36.84%] max-w-full overflow-hidden max-h-full z-[1]"
                      alt=""
                      src="/vector-22.svg"
                    />
                  </button>
                  <div className="flex flex-col items-start justify-start pt-1 px-0 pb-0">
                    <div className="flex flex-col items-start justify-start gap-[3.4px]">
                      <div className="relative capitalize font-medium inline-block min-w-[38px] z-[1]">
                        Food
                      </div>
                      <div className="relative text-xs capitalize font-semibold text-ocean-blue-button inline-block min-w-[96px] whitespace-nowrap z-[1]">
                        19:30 - March 31
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col items-start justify-end pt-0 pb-[4.4px] pr-[12.4px] pl-0 text-smi">
                  <div className="h-[35.5px] flex flex-row items-end justify-start gap-[9.5px]">
                    <div className="h-[36.5px] w-px relative box-border z-[1] border-r-[1px] border-solid border-main-green" />
                    <div className="flex flex-col items-start justify-end pt-0 px-0 pb-[9.6px]">
                      <div className="relative leading-[15px] font-light inline-block min-w-[42px] z-[1]">
                        Dinner
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col items-start justify-end pt-0 px-0 pb-[4.4px] text-right text-ocean-blue-button">
                  <div className="h-[35.5px] flex flex-row items-end justify-start gap-[4.1px]">
                    <div className="h-[36.5px] w-px relative box-border z-[1] border-r-[1px] border-solid border-main-green" />
                    <div className="flex flex-col items-start justify-end pt-0 px-0 pb-[5.6px]">
                      <div className="relative capitalize font-medium inline-block min-w-[60px] z-[1]">
                        -$70,40
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="w-[312.9px] flex flex-row items-start justify-start py-0 pr-5 pl-0 box-border gap-[17px]">
              <img
                className="h-[53px] w-[57px] relative z-[1]"
                alt=""
                src="/icon-rent.svg"
              />
              <div className="flex-1 flex flex-col items-start justify-start pt-1 pb-0 pr-5 pl-0">
                <div className="relative capitalize font-medium inline-block min-w-[35px] z-[1]">
                  Rent
                </div>
              </div>
              <div className="w-[76.4px] flex flex-col items-start justify-start pt-[12.1px] px-0 pb-0 box-border">
                <div className="w-px h-[35.5px] relative">
                  <div className="absolute top-[0px] left-[0px] box-border w-full h-full z-[1] border-r-[1px] border-solid border-main-green" />
                  <div className="absolute top-[0px] left-[0px] box-border w-full h-full z-[2] border-r-[1px] border-solid border-main-green" />
                </div>
              </div>
              <div className="flex flex-col items-start justify-start pt-[12.1px] px-0 pb-0">
                <div className="w-px h-[35.5px] relative">
                  <div className="absolute top-[0px] left-[0px] box-border w-full h-full z-[2] border-r-[1px] border-solid border-main-green" />
                  <div className="absolute top-[0px] left-[0px] box-border w-full h-full z-[3] border-r-[1px] border-solid border-main-green" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <FrameComponent7 />
      <section className="absolute top-[762px] left-[0px] shadow-[1px_0px_8px_rgba(0,_0,_0,_0.25)] rounded-t-11xl rounded-b-none bg-white w-[393px] flex flex-row items-start justify-start pt-8 px-[50px] pb-[29px] box-border gap-[67px] max-w-full z-[4]">
        <div className="h-[87px] w-[393px] relative shadow-[1px_0px_8px_rgba(0,_0,_0,_0.25)] rounded-t-11xl rounded-b-none bg-white hidden max-w-full z-[0]" />
        <img
          className="h-[26px] w-[26px] relative overflow-hidden shrink-0 min-h-[26px] cursor-pointer z-[5]"
          loading="lazy"
          alt=""
          src="/home3line2.svg"
          onClick={onHome3LineIconClick}
        />
        <img
          className="h-[26px] w-[26px] relative overflow-hidden shrink-0 min-h-[26px] z-[5]"
          loading="lazy"
          alt=""
          src="/refundline2.svg"
        />
        <img
          className="h-[26px] w-[26px] relative overflow-hidden shrink-0 min-h-[26px] z-[5]"
          loading="lazy"
          alt=""
          src="/barchartgroupedline1.svg"
        />
        <img
          className="h-[26px] w-[26px] absolute !m-[0] right-[38px] bottom-[29px] overflow-hidden shrink-0 z-[5]"
          loading="lazy"
          alt=""
          src="/settings2line1.svg"
        />
      </section>
      <div className="relative w-[100px] h-[100px] z-[2]" />
    </div>
  );
};

export default CTransactionIncome;
