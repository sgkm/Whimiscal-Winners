import { FunctionComponent, useCallback } from "react";
import FrameComponent1 from "../components/frame-component1";
import FrameComponent from "../components/frame-component";
import { useNavigate } from "react-router-dom";

const Analytics: FunctionComponent = () => {
  const navigate = useNavigate();

  const onHome3LineIconClick = useCallback(() => {
    navigate("/home");
  }, [navigate]);

  const onRefundLineIconClick = useCallback(() => {
    navigate("/add-card");
  }, [navigate]);

  const onSettings2LineIconClick = useCallback(() => {
    navigate("/profile");
  }, [navigate]);

  return (
    <div className="w-full relative rounded-xl bg-gray-100 overflow-hidden flex flex-col items-end justify-start pt-[70px] px-0 pb-0 box-border gap-[21px] leading-[normal] tracking-[normal]">
      <FrameComponent1 />
      <section className="self-stretch flex flex-col items-start justify-start pt-0 pb-2.5 pr-0 pl-[15px] box-border gap-[27px] max-w-full text-left text-3xl text-black font-kontora">
        <div className="w-[395px] flex flex-row items-start justify-start py-0 pr-[17px] pl-0 box-border gap-[5px] max-w-[105%] shrink-0">
          <button className="cursor-pointer [border:none] pt-2.5 pb-3 pr-[22px] pl-[25px] bg-seagreen flex-[0.6667] rounded-31xl flex flex-row items-start justify-start box-border min-w-[42px] whitespace-nowrap mq74:flex-1">
            <div className="h-[38px] w-[75px] relative rounded-31xl bg-seagreen hidden" />
            <b className="relative text-smi inline-block font-inter text-white text-left min-w-[28px] z-[2]">
              24 h
            </b>
          </button>
          <button className="cursor-pointer pt-[7px] pb-[9px] pr-[17px] pl-[18px] bg-[transparent] flex-[0.8571] rounded-31xl box-border flex flex-row items-start justify-start min-w-[42px] border-[2px] border-solid border-seagreen mq74:flex-1">
            <div className="h-[38px] w-[75px] relative rounded-31xl box-border hidden border-[2px] border-solid border-seagreen" />
            <b className="relative text-smi inline-block font-inter text-seagreen text-left min-w-[36px] z-[2]">
              Week
            </b>
          </button>
          <button className="cursor-pointer [border:none] pt-2.5 pb-3 pr-4 pl-[17px] bg-seagreen flex-1 rounded-31xl flex flex-row items-start justify-start box-border min-w-[42px]">
            <div className="h-[38px] w-[75px] relative rounded-31xl bg-seagreen hidden" />
            <b className="relative text-smi inline-block font-inter text-white text-left min-w-[42px] z-[2]">
              Month
            </b>
          </button>
          <button className="cursor-pointer [border:none] py-[11px] px-[23px] bg-seagreen flex-[0.6905] rounded-31xl flex flex-row items-start justify-start box-border min-w-[42px] mq74:flex-1">
            <div className="h-[38px] w-[75px] relative rounded-31xl bg-seagreen hidden" />
            <b className="relative text-smi inline-block font-inter text-white text-left min-w-[29px] z-[2]">
              Year
            </b>
          </button>
          <button className="cursor-pointer [border:none] p-0 bg-[transparent] h-[38px] w-[58px] relative">
            <div className="absolute top-[0px] left-[0px] rounded-31xl bg-seagreen w-[75px] h-[38px]" />
            <img
              className="absolute top-[10px] left-[27px] w-[22px] h-[18px] z-[1]"
              loading="lazy"
              alt=""
              src="/vector.svg"
            />
          </button>
        </div>
        <h1 className="m-0 h-[22px] relative text-inherit font-extrabold font-inherit inline-block">
          Your Expenses
        </h1>
      </section>
      <FrameComponent />
      <div className="w-[339px] h-px absolute !m-[0] top-[312px] right-[14px] box-border border-t-[1px] border-dashed border-darkgray-100" />
      <section className="self-stretch flex flex-row items-start justify-end py-0 pr-2 pl-2.5 box-border max-w-full text-left text-3xl text-black font-kontora">
        <div className="flex-1 flex flex-col items-start justify-start gap-[17px] max-w-full">
          <div className="flex flex-row items-start justify-start py-0 px-[5px]">
            <h1 className="m-0 h-[22px] relative text-inherit font-extrabold font-inherit inline-block min-w-[103px] whitespace-nowrap">
              10 May, Fri
            </h1>
          </div>
          <div className="self-stretch flex flex-row items-end justify-between gap-[20px] text-2xs font-inter">
            <div className="flex flex-col items-start justify-start gap-[17.5px]">
              <div className="flex flex-row items-start justify-start py-0 pr-[9px] pl-0 gap-[14px]">
                <img
                  className="h-10 w-10 relative rounded-xl overflow-hidden shrink-0"
                  loading="lazy"
                  alt=""
                  src="/exchangedollarline.svg"
                />
                <div className="flex flex-col items-start justify-start pt-1 px-0 pb-0">
                  <div className="flex flex-col items-start justify-start gap-[4px]">
                    <div className="relative font-extrabold inline-block min-w-[25px]">
                      ABC
                    </div>
                    <div className="relative font-medium text-darkgray-100 inline-block min-w-[44px]">
                      Transfer
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex flex-row items-end justify-start py-0 pr-0.5 pl-0 gap-[14px]">
                <img
                  className="h-10 w-10 relative rounded-xl overflow-hidden shrink-0"
                  loading="lazy"
                  alt=""
                  src="/netflixfill.svg"
                />
                <div className="flex flex-col items-start justify-end pt-0 px-0 pb-[5px]">
                  <div className="flex flex-col items-start justify-start gap-[3px]">
                    <div className="relative font-extrabold inline-block min-w-[24px]">
                      XYZ
                    </div>
                    <div className="relative font-medium text-darkgray-100 inline-block min-w-[51px]">
                      Shopping
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex flex-row items-start justify-start py-0 pr-0 pl-px">
                <div className="flex flex-row items-end justify-start gap-[13px]">
                  <img
                    className="h-10 w-10 relative rounded-xl overflow-hidden shrink-0"
                    loading="lazy"
                    alt=""
                    src="/restaurant2fill.svg"
                  />
                  <div className="flex flex-col items-start justify-end pt-0 px-0 pb-1">
                    <div className="flex flex-col items-start justify-start gap-[1px]">
                      <div className="relative font-extrabold inline-block min-w-[53px]">
                        Delhivery
                      </div>
                      <div className="relative font-medium text-darkgray-100 inline-block min-w-[27px]">
                        Food
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex flex-col items-start justify-end pt-0 px-0 pb-[7px]">
              <div className="flex flex-col items-start justify-start gap-[53px]">
                <div className="relative font-extrabold inline-block min-w-[48px]">
                  - $53.00
                </div>
                <div className="flex flex-col items-start justify-start gap-[45px]">
                  <div className="relative font-extrabold inline-block min-w-[49px]">
                    - $45.00
                  </div>
                  <div className="relative font-extrabold inline-block min-w-[48px]">
                    - $20.00
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="self-stretch shadow-[1px_0px_8px_rgba(0,_0,_0,_0.25)] rounded-t-11xl rounded-b-none bg-white flex flex-row items-start justify-start pt-8 px-[41px] pb-[29px] box-border relative gap-[67px] max-w-full">
        <div className="h-[87px] w-[393px] relative shadow-[1px_0px_8px_rgba(0,_0,_0,_0.25)] rounded-t-11xl rounded-b-none bg-white hidden max-w-full z-[0]" />
        <img
          className="h-[26px] w-[26px] relative overflow-hidden shrink-0 min-h-[26px] cursor-pointer z-[1]"
          loading="lazy"
          alt=""
          src="/home3line1.svg"
          onClick={onHome3LineIconClick}
        />
        <img
          className="h-[26px] w-[26px] relative overflow-hidden shrink-0 min-h-[26px] cursor-pointer z-[1]"
          loading="lazy"
          alt=""
          src="/refundline2.svg"
          onClick={onRefundLineIconClick}
        />
        <img
          className="h-[26px] w-[26px] relative overflow-hidden shrink-0 min-h-[26px] z-[1]"
          loading="lazy"
          alt=""
          src="/barchartgroupedline2.svg"
        />
        <img
          className="h-[26px] w-[26px] absolute !m-[0] right-[47px] bottom-[29px] overflow-hidden shrink-0 cursor-pointer z-[1]"
          loading="lazy"
          alt=""
          src="/settings2line1.svg"
          onClick={onSettings2LineIconClick}
        />
      </section>
    </div>
  );
};

export default Analytics;
