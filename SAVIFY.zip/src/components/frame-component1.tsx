import { FunctionComponent } from "react";

const FrameComponent1: FunctionComponent = () => {
  return (
    <div className="self-stretch flex flex-row items-start justify-end pt-0 px-[15px] pb-[19px] box-border max-w-full text-left text-3xl text-black font-inter">
      <div className="flex-1 flex flex-row items-start justify-between max-w-full gap-[20px]">
        <div className="flex flex-col items-start justify-start pt-px pb-0 pr-[35px] pl-0">
          <img
            className="w-[30px] h-[30px] relative rounded-lg overflow-hidden shrink-0"
            loading="lazy"
            alt=""
            src="/arrowleftsline.svg"
          />
        </div>
        <div className="flex flex-col items-start justify-start pt-0.5 px-0 pb-0">
          <h1 className="m-0 relative text-inherit font-bold font-inherit inline-block min-w-[102px]">
            Analytics
          </h1>
        </div>
        <button className="cursor-pointer [border:none] pt-[3px] px-5 pb-[5px] bg-white shadow-[0px_0px_5px_rgba(0,_0,_0,_0.25)] rounded-21xl flex flex-row items-start justify-start">
          <div className="h-8 w-16 relative shadow-[0px_0px_5px_rgba(0,_0,_0,_0.25)] rounded-21xl bg-white hidden" />
          <img
            className="h-6 w-6 relative overflow-hidden shrink-0 z-[1]"
            loading="lazy"
            alt=""
            src="/download2fill.svg"
          />
        </button>
      </div>
    </div>
  );
};

export default FrameComponent1;
