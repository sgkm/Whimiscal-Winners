import { FunctionComponent } from "react";
import FrameComponent4 from "./frame-component4";

const FrameComponent9: FunctionComponent = () => {
  return (
    <section className="self-stretch flex flex-row items-start justify-end pt-0 pb-[26px] pr-[17px] pl-[19px] box-border max-w-full">
      <div className="flex-1 flex flex-col items-start justify-start gap-[17px] max-w-full">
        <FrameComponent4
          eNTERINCOMEINR="ENTER EXPECTED LOAN AMOUNT (INR)"
          frame1Placeholder="00.00"
          propAlignSelf="stretch"
          propDisplay="unset"
          propMinWidth="unset"
        />
        <FrameComponent4
          eNTERINCOMEINR="Date of birth"
          frame1Placeholder="DD / MM /YYY"
          propAlignSelf="unset"
          propDisplay="inline-block"
          propMinWidth="95px"
        />
      </div>
    </section>
  );
};

export default FrameComponent9;
