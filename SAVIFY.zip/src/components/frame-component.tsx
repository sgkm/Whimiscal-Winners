import { FunctionComponent } from "react";

const FrameComponent: FunctionComponent = () => {
  return (
    <section className="self-stretch flex flex-row items-start justify-end pt-0 pb-3 pr-[9px] pl-2.5 box-border max-w-full text-left text-2xs text-darkgray-100 font-kontora">
      <div className="flex-1 flex flex-col items-start justify-start gap-[13px] max-w-full">
        <div className="self-stretch flex flex-row items-start justify-start py-0 pr-1.5 pl-[5px] box-border max-w-full">
          <div className="flex-1 flex flex-row flex-wrap items-start justify-start gap-[4px] max-w-full">
            <div className="flex flex-col items-start justify-start gap-[35px]">
              <div className="relative font-extrabold inline-block min-w-[19px]">
                950
              </div>
              <div className="relative font-extrabold inline-block min-w-[18px]">
                725
              </div>
              <div className="relative font-extrabold inline-block min-w-[19px]">
                430
              </div>
              <div className="relative font-extrabold inline-block min-w-[21px]">
                200
              </div>
              <div className="w-2 relative font-extrabold text-right inline-block min-w-[8px]">
                0
              </div>
            </div>
            <div className="flex-1 flex flex-col items-start justify-start pt-[5px] px-0 pb-0 box-border min-w-[220px] max-w-full text-black font-inter">
              <div className="self-stretch flex flex-col items-start justify-start gap-[4.5px] max-w-full">
                <div className="self-stretch h-px relative box-border border-t-[1px] border-dashed border-darkgray-100" />
                <div className="w-[338px] h-[180px] relative overflow-x-auto shrink-0 max-w-full">
                  <div className="absolute top-[25px] left-[7px] rounded-t-lg rounded-b-none bg-gainsboro w-[31px] h-[154px] z-[1]" />
                  <div className="absolute top-[65px] left-[55px] rounded-t-lg rounded-b-none bg-gainsboro w-[31px] h-[114px] z-[1]" />
                  <div className="absolute top-[35px] left-[103px] rounded-t-lg rounded-b-none bg-gainsboro w-[31px] h-36 z-[1]" />
                  <div className="absolute top-[14px] left-[151px] rounded-t-lg rounded-b-none bg-gainsboro w-[31px] h-[165px] z-[1]" />
                  <div className="absolute top-[44px] left-[199px] flex flex-row items-start justify-start">
                    <div className="h-px w-[339px] absolute !m-[0] top-[43px] left-[-199px] box-border border-t-[1px] border-dashed border-darkgray-100" />
                    <div className="h-px w-[339px] absolute !m-[0] bottom-[45px] left-[-199px] box-border border-t-[1px] border-dashed border-darkgray-100" />
                    <div className="rounded-t-lg rounded-b-none bg-plum flex flex-row items-start justify-start pt-[43px] px-0 pb-0 z-[1]">
                      <div className="h-[135px] w-[31px] relative rounded-t-lg rounded-b-none bg-plum hidden" />
                      <div className="h-[92px] w-[31px] relative bg-seagreen z-[3]">
                        <div className="absolute top-[0px] left-[0px] bg-seagreen w-full h-full hidden z-[3]" />
                        <div className="absolute top-[59px] left-[0px] bg-black w-[31px] h-[33px] z-[4]" />
                      </div>
                    </div>
                  </div>
                  <div className="absolute top-[54px] left-[247px] rounded-t-lg rounded-b-none bg-gainsboro w-[31px] h-[125px] z-[1]" />
                  <div className="absolute top-[0px] left-[295px] rounded-t-lg rounded-b-none bg-gainsboro w-[31px] h-[179px] z-[1]" />
                  <div className="absolute top-[179px] left-[0px] box-border w-[339px] h-px z-[2] border-t-[1px] border-dashed border-darkgray-100" />
                  <div className="absolute top-[22px] left-[199px] font-extrabold inline-block min-w-[30px] whitespace-nowrap">
                    $700
                  </div>
                </div>
                <div className="self-stretch flex flex-row items-start justify-start py-0 pr-[17px] pl-3 text-right text-darkgray-100 font-kontora">
                  <div className="flex-1 flex flex-row items-start justify-between gap-[20px]">
                    <div className="relative font-extrabold inline-block min-w-[22px]">
                      Mon
                    </div>
                    <div className="relative font-extrabold inline-block min-w-[18px]">
                      Tue
                    </div>
                    <div className="w-6 relative font-extrabold inline-block min-w-[24px]">
                      Wed
                    </div>
                    <div className="relative font-extrabold inline-block min-w-[20px]">
                      Thu
                    </div>
                    <div className="relative font-extrabold inline-block min-w-[15px]">
                      Fri
                    </div>
                    <div className="w-[17px] relative font-extrabold inline-block min-w-[17px]">
                      Sat
                    </div>
                    <div className="relative font-extrabold inline-block min-w-[19px]">
                      Sun
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="self-stretch flex flex-row items-end justify-start gap-[10px] text-white font-inter">
          <div className="rounded-mini bg-seagreen flex flex-row items-start justify-start py-3 px-[21px] whitespace-nowrap">
            <div className="h-[37px] w-[118px] relative rounded-mini bg-seagreen hidden" />
            <div className="relative inline-block min-w-[76px] z-[1]">
              <span className="font-medium">Grocery</span>
              <span className="font-extrabold font-kontora">{` `}</span>
              <span className="font-extrabold">$300</span>
            </div>
          </div>
          <div className="rounded-mini bg-plum flex flex-row items-start justify-start py-3 pr-[17px] pl-[18px] whitespace-nowrap">
            <div className="h-[37px] w-[118px] relative rounded-mini bg-plum hidden" />
            <div className="relative inline-block min-w-[83px] z-[1]">
              <span className="font-medium">Shopping</span>
              <span className="font-extrabold font-kontora">{` `}</span>
              <span className="font-extrabold">$250</span>
            </div>
          </div>
          <div className="flex flex-col items-start justify-end pt-0 px-0 pb-px">
            <div className="rounded-mini bg-black flex flex-row items-start justify-start pt-[13px] pb-[11px] pr-[21px] pl-[22px] whitespace-nowrap">
              <div className="h-[37px] w-[118px] relative rounded-mini bg-black hidden" />
              <div className="relative inline-block min-w-[75px] z-[1]">
                <span className="font-medium">Transfer</span>
                <span className="font-extrabold font-kontora">{` `}</span>
                <span className="font-extrabold">$150</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FrameComponent;
