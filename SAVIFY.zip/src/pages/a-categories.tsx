import { FunctionComponent, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const ACategories: FunctionComponent = () => {
  const [checkIconChecked, setCheckIconChecked] = useState(true);
  const navigate = useNavigate();

  const onHome3LineIconClick = useCallback(() => {
    navigate("/home");
  }, [navigate]);

  return (
    <div className="w-full relative rounded-21xl bg-main-green overflow-hidden flex flex-col items-end justify-start pt-[61px] px-9 pb-[161px] box-border gap-[46px] leading-[normal] tracking-[normal]">
      <section className="self-stretch flex flex-col items-start justify-start pt-0 px-0 pb-[7px] box-border gap-[11px] max-w-full text-left text-xl text-letters-and-icons font-subtitle">
        <div className="self-stretch flex flex-row flex-wrap items-start justify-start gap-[3px] max-w-full">
          <div className="flex flex-col items-start justify-start pt-2 px-0 pb-0">
            <img
              className="w-[19px] h-4 relative"
              loading="lazy"
              alt=""
              src="/bring-back.svg"
            />
          </div>
          <div className="flex-1 flex flex-col items-end justify-start gap-[45px] min-w-[217px] max-w-full mq334:gap-[22px]">
            <div className="w-[241px] flex flex-row items-start justify-between gap-[20px]">
              <div className="w-[125px] flex flex-col items-start justify-start pt-[3px] px-0 pb-0 box-border">
                <div className="self-stretch relative leading-[22px] capitalize font-semibold">
                  Categories
                </div>
              </div>
              <img
                className="h-[30px] w-[30px] relative rounded-[25.71px] overflow-hidden shrink-0"
                loading="lazy"
                alt=""
                src="/iconnotification.svg"
              />
            </div>
            <div className="self-stretch flex flex-row items-start justify-end py-0 pr-[25px] pl-0 text-xs">
              <div className="flex-1 flex flex-row items-start justify-start gap-[32px] mq309:gap-[16px] mq344:flex-wrap">
                <div className="flex-[0.9435] flex flex-col items-start justify-start py-0 pr-[7px] pl-0 box-border min-w-[81px] mq381:flex-1">
                  <div className="flex flex-row items-start justify-start gap-[6px] shrink-0 [debug_commit:1de1738]">
                    <div className="flex flex-col items-start justify-start pt-[3px] px-0 pb-0">
                      <div className="w-3 h-3 relative">
                        <img
                          className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] max-w-full overflow-hidden max-h-full object-contain"
                          loading="lazy"
                          alt=""
                          src="/income@2x.png"
                        />
                      </div>
                    </div>
                    <div className="relative capitalize inline-block min-w-[82px] z-[1]">
                      Total Balance
                    </div>
                  </div>
                  <div className="h-[34px] flex flex-row items-start justify-start pt-0 px-0 pb-0 box-border text-5xl text-honeydew">
                    <b className="mt-[-2px] relative capitalize inline-block min-w-[117px] shrink-0 [debug_commit:1de1738] whitespace-nowrap">
                      $7,783.00
                    </b>
                  </div>
                </div>
                <div className="h-[43px] w-px relative box-border border-r-[1px] border-solid border-light-green mq344:w-full mq344:h-px" />
                <div className="flex-1 flex flex-col items-start justify-start pt-px px-0 pb-0 box-border min-w-[78px]">
                  <div className="self-stretch flex flex-col items-start justify-start">
                    <div className="flex flex-row items-start justify-start gap-[7px] shrink-0 [debug_commit:1de1738]">
                      <div className="flex flex-col items-start justify-start pt-0.5 px-0 pb-0">
                        <div className="w-3 h-3 relative">
                          <div className="absolute h-3 w-3 top-[0%] right-[0%] bottom-[0%] left-[0%]">
                            <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-[3px] box-border border-[1px] border-solid border-gray-400" />
                            <img
                              className="absolute h-3/6 w-6/12 top-[25%] right-[25%] bottom-[25%] left-[25%] max-w-full overflow-hidden max-h-full object-contain z-[1]"
                              loading="lazy"
                              alt=""
                              src="/arrow-1.svg"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="relative capitalize inline-block min-w-[82px] z-[1]">
                        Total Expense
                      </div>
                    </div>
                    <div className="h-[33px] flex flex-row items-start justify-start pt-0 px-0 pb-0 box-border text-5xl text-ocean-blue-button">
                      <div className="mt-[-3px] relative capitalize font-semibold inline-block min-w-[120px] shrink-0 [debug_commit:1de1738]">
                        -$1.187.40
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="self-stretch flex flex-row items-start justify-start py-0 pr-3.5 pl-3 box-border max-w-full text-xs text-honeydew">
          <div className="flex-1 rounded-sm-5 bg-gray-400 flex flex-row items-end justify-start py-0 pr-0 pl-[21px] box-border gap-[24px] max-w-full mq381:flex-wrap mq381:p-5 mq381:box-border">
            <div className="self-stretch w-[330px] relative rounded-sm-5 bg-gray-400 hidden max-w-full" />
            <div className="flex flex-col items-start justify-end pt-0 px-0 pb-[3px]">
              <div className="relative capitalize inline-block min-w-[24px] z-[1]">
                30%
              </div>
            </div>
            <div className="flex-1 rounded-sm-5 bg-honeydew flex flex-row items-start justify-end pt-[3px] px-[13px] pb-1 box-border min-w-[73px] z-[1] text-smi text-gray-400">
              <div className="h-[27px] w-[261px] relative rounded-sm-5 bg-honeydew hidden" />
              <i className="relative capitalize inline-block font-medium min-w-[73px] whitespace-nowrap z-[2]">
                $20,000.00
              </i>
            </div>
          </div>
        </div>
        <div className="flex flex-row items-start justify-start py-0 px-[22px] box-border max-w-full text-mini text-gray-400">
          <div className="flex flex-row items-start justify-start gap-[10px]">
            <div className="flex flex-col items-start justify-start pt-1.5 px-0 pb-0">
              <input
                className="accent-teal m-0 w-[11px] h-[11px] relative"
                checked={checkIconChecked}
                type="checkbox"
                onChange={(event) => setCheckIconChecked(event.target.checked)}
              />
            </div>
            <div className="relative capitalize">
              30% of your expenses, looks good.
            </div>
          </div>
        </div>
      </section>
      <section className="self-stretch flex flex-row flex-wrap items-start justify-start gap-[21px] text-left text-mini text-letters-and-icons font-subtitle">
        <div className="flex-1 flex flex-col items-start justify-start gap-[2.4px] min-w-[79px]">
          <button className="cursor-pointer [border:none] p-0 bg-[transparent] self-stretch flex flex-row items-start justify-start shrink-0 [debug_commit:1de1738] z-[1]">
            <div className="h-[97.6px] flex-1 relative">
              <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-[25.79px] bg-ocean-blue-button" />
              <img
                className="absolute h-[55.74%] w-[29.14%] top-[22.54%] right-[35.62%] bottom-[21.72%] left-[35.24%] max-w-full overflow-hidden max-h-full z-[1]"
                alt=""
                src="/vector3.svg"
              />
            </div>
          </button>
          <div className="flex flex-row items-start justify-start py-0 px-7">
            <div className="relative capitalize font-medium inline-block min-w-[38px] shrink-0 [debug_commit:1de1738] z-[1]">
              Food
            </div>
          </div>
        </div>
        <div className="flex-1 flex flex-col items-start justify-start gap-[2.4px] min-w-[79px]">
          <button className="cursor-pointer [border:none] p-0 bg-[transparent] self-stretch flex flex-row items-start justify-start shrink-0 [debug_commit:1de1738] z-[1]">
            <div className="h-[97.6px] flex-1 relative">
              <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-[25.79px] bg-light-blue-button" />
              <img
                className="absolute h-[46.11%] w-[42.76%] top-[26.64%] right-[28.67%] bottom-[27.25%] left-[28.57%] max-w-full overflow-hidden max-h-full z-[1]"
                alt=""
                src="/vector-11.svg"
              />
            </div>
          </button>
          <div className="flex flex-row items-start justify-start py-0 pr-[15px] pl-4">
            <div className="relative capitalize font-medium inline-block min-w-[74px] shrink-0 [debug_commit:1de1738] z-[1]">
              Transport
            </div>
          </div>
        </div>
        <div className="flex-1 flex flex-col items-start justify-start gap-[2.4px] min-w-[79px]">
          <button className="cursor-pointer [border:none] p-0 bg-[transparent] self-stretch flex flex-row items-start justify-start shrink-0 [debug_commit:1de1738] z-[1]">
            <div className="h-[97.6px] flex-1 relative">
              <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-[25.79px] bg-light-blue-button" />
              <img
                className="absolute h-[47.13%] w-[33.71%] top-[26.64%] right-[32.95%] bottom-[26.23%] left-[33.33%] max-w-full overflow-hidden max-h-full z-[1]"
                alt=""
                src="/vector-21.svg"
              />
            </div>
          </button>
          <div className="flex flex-row items-start justify-start py-0 px-[18px]">
            <div className="relative capitalize font-medium inline-block min-w-[69px] shrink-0 [debug_commit:1de1738] z-[1]">
              Medicine
            </div>
          </div>
        </div>
      </section>
      <section className="self-stretch flex flex-row items-start justify-start gap-[17px] text-left text-mini text-letters-and-icons font-subtitle mq358:flex-wrap">
        <div className="flex-1 flex flex-col items-start justify-start gap-[39px] min-w-[153px]">
          <div className="self-stretch h-[123px] flex flex-col items-start justify-start gap-[1.4px]">
            <div className="self-stretch flex-1 flex flex-row items-start justify-start gap-[21px]">
              <button className="cursor-pointer [border:none] p-0 bg-[transparent] flex-1 flex flex-row items-start justify-start z-[1]">
                <div className="h-[97.6px] flex-1 relative">
                  <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-[25.79px] bg-light-blue-button" />
                  <img
                    className="absolute h-[54.71%] w-[31.05%] top-[22.54%] right-[34.67%] bottom-[22.75%] left-[34.29%] max-w-full overflow-hidden max-h-full z-[1]"
                    alt=""
                    src="/vector-3.svg"
                  />
                </div>
              </button>
              <div className="self-stretch flex-1 flex flex-col items-start justify-start pt-px px-0 pb-0">
                <img
                  className="self-stretch flex-1 relative max-w-full overflow-hidden max-h-full z-[1]"
                  loading="lazy"
                  alt=""
                  src="/rent-funtional.svg"
                />
              </div>
            </div>
            <div className="w-[212px] flex flex-row items-start justify-start py-0 px-4 box-border">
              <div className="flex-1 flex flex-row items-start justify-between gap-[20px]">
                <div className="relative capitalize font-medium inline-block min-w-[73px] z-[1]">
                  Groceries
                </div>
                <div className="relative capitalize font-medium inline-block min-w-[35px] z-[1]">
                  Rent
                </div>
              </div>
            </div>
          </div>
          <div className="self-stretch flex flex-row items-start justify-start gap-[22px]">
            <div className="flex-1 flex flex-col items-start justify-start gap-[5.4px]">
              <button className="cursor-pointer [border:none] p-0 bg-[transparent] self-stretch flex flex-row items-start justify-start shrink-0 [debug_commit:1de1738] z-[1]">
                <div className="h-[97.6px] flex-1 relative">
                  <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-[25.79px] bg-light-blue-button" />
                  <img
                    className="absolute h-[39.96%] w-[39.05%] top-[29.71%] right-[30.48%] bottom-[30.33%] left-[30.48%] max-w-full overflow-hidden max-h-full z-[1]"
                    alt=""
                    src="/vector-4.svg"
                  />
                </div>
              </button>
              <div className="flex flex-row items-start justify-start py-0 pr-[23px] pl-[22px]">
                <div className="relative capitalize font-medium inline-block min-w-[60px] shrink-0 [debug_commit:1de1738] z-[1]">
                  Savings
                </div>
              </div>
            </div>
            <div className="flex-1 flex flex-col items-start justify-start gap-[5.4px]">
              <div className="self-stretch flex flex-row items-start justify-start py-0 pr-px pl-0.5">
                <button className="cursor-pointer [border:none] p-0 bg-[transparent] flex-1 flex flex-row items-start justify-start shrink-0 [debug_commit:1de1738] z-[1]">
                  <div className="h-[97.6px] flex-1 relative">
                    <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-[25.79px] bg-light-blue-button" />
                    <img
                      className="absolute h-[51.33%] w-[46.38%] top-[24.59%] right-[26.67%] bottom-[24.08%] left-[26.95%] max-w-full overflow-hidden max-h-full object-contain z-[1]"
                      alt=""
                      src="/vector-5.svg"
                    />
                  </div>
                </button>
              </div>
              <div className="relative capitalize font-medium inline-block min-w-[108px] shrink-0 [debug_commit:1de1738] z-[1]">
                Entertainment
              </div>
            </div>
          </div>
        </div>
        <div className="w-[105px] flex flex-col items-start justify-start gap-[39px] min-w-[105px] mq358:flex-1">
          <div className="self-stretch flex flex-col items-start justify-start gap-[2.4px]">
            <button className="cursor-pointer [border:none] p-0 bg-[transparent] self-stretch flex flex-row items-start justify-start shrink-0 [debug_commit:1de1738] z-[1]">
              <div className="h-[97.6px] flex-1 relative">
                <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-[25.79px] bg-light-blue-button" />
                <img
                  className="absolute h-[50.51%] w-[44.57%] top-[24.59%] right-[27.81%] bottom-[24.9%] left-[27.62%] max-w-full overflow-hidden max-h-full z-[1]"
                  alt=""
                  src="/vector-6.svg"
                />
              </div>
            </button>
            <div className="flex flex-row items-start justify-start py-0 px-[35px]">
              <div className="relative capitalize font-medium inline-block min-w-[35px] shrink-0 [debug_commit:1de1738] z-[1]">
                Gifts
              </div>
            </div>
          </div>
          <div className="self-stretch flex flex-col items-start justify-start gap-[5.4px]">
            <button className="cursor-pointer [border:none] p-0 bg-[transparent] self-stretch flex flex-row items-start justify-start shrink-0 [debug_commit:1de1738] z-[1]">
              <div className="h-[97.6px] flex-1 relative">
                <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-[25.79px] bg-light-blue-button" />
                <img
                  className="absolute h-[39.96%] w-[37.14%] top-[30.74%] right-[31.43%] bottom-[29.3%] left-[31.43%] max-w-full overflow-hidden max-h-full z-[1]"
                  alt=""
                  src="/group-390.svg"
                />
              </div>
            </button>
            <div className="flex flex-row items-start justify-start py-0 pr-[33px] pl-[34px]">
              <div className="relative capitalize font-medium inline-block min-w-[38px] shrink-0 [debug_commit:1de1738] z-[1]">
                More
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="w-full h-[651px] absolute !m-[0] right-[0px] bottom-[0px] left-[0px]">
        <img
          className="absolute top-[0px] left-[0px] w-full h-full"
          alt=""
          src="/rectangle-148.svg"
        />
        <footer className="absolute top-[561px] left-[0px] shadow-[1px_0px_8px_rgba(0,_0,_0,_0.25)] rounded-t-11xl rounded-b-none bg-white w-[430px] h-[87px] z-[1]">
          <div className="absolute top-[0px] left-[0px] shadow-[1px_0px_8px_rgba(0,_0,_0,_0.25)] rounded-t-11xl rounded-b-none bg-white w-full h-full hidden" />
          <img
            className="absolute top-[32px] left-[45px] w-[26px] h-[26px] overflow-hidden cursor-pointer z-[2]"
            loading="lazy"
            alt=""
            src="/home3line2.svg"
            onClick={onHome3LineIconClick}
          />
          <img
            className="absolute top-[32px] left-[138px] w-[26px] h-[26px] overflow-hidden z-[2]"
            loading="lazy"
            alt=""
            src="/refundline2.svg"
          />
          <img
            className="absolute top-[32px] left-[231px] w-[26px] h-[26px] overflow-hidden z-[2]"
            loading="lazy"
            alt=""
            src="/barchartgroupedline1.svg"
          />
          <img
            className="absolute top-[32px] left-[324px] w-[26px] h-[26px] overflow-hidden z-[2]"
            loading="lazy"
            alt=""
            src="/settings2line1.svg"
          />
        </footer>
      </section>
    </div>
  );
};

export default ACategories;
