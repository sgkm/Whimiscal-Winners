import { FunctionComponent } from "react";

const SignUpLink: FunctionComponent = () => {
  return (
    <section className="w-[321px] flex flex-row items-start justify-start py-0 px-6 box-border max-w-full text-center text-smi text-letters-and-icons font-paragraph">
      <div className="flex-1 flex flex-col items-start justify-start gap-[20.3px]">
        <div className="self-stretch flex flex-row items-start justify-start py-0 px-[77px]">
          <div className="flex-1 flex flex-col items-end justify-start gap-[15px]">
            <div className="self-stretch relative leading-[15px] font-light z-[1]">
              or sign up with
            </div>
            <div className="flex flex-row items-start justify-end py-0 pr-[2.3px] pl-0.5">
              <div className="flex flex-row items-start justify-start gap-[17.3px]">
                <img
                  className="h-[32.6px] w-[32.7px] relative min-h-[33px] z-[1]"
                  loading="lazy"
                  alt=""
                  src="/facebook.svg"
                />
                <img
                  className="h-[32.7px] w-[32.7px] relative min-h-[33px] z-[1]"
                  loading="lazy"
                  alt=""
                  src="/google.svg"
                />
              </div>
            </div>
          </div>
        </div>
        <div className="self-stretch relative leading-[15px] font-light z-[1]">
          <span>{`Don’t have an account? `}</span>
          <span className="text-blue-button">Sign Up</span>
        </div>
      </div>
    </section>
  );
};

export default SignUpLink;
