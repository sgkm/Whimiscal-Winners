import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const RecentTransactionsLabel1: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrameButtonClick = useCallback(() => {
    navigate("/sent");
  }, [navigate]);

  const onFrameButton1Click = useCallback(() => {
    navigate("/received");
  }, [navigate]);

  const onFrameButton2Click = useCallback(() => {
    navigate("/loan-prediction");
  }, [navigate]);

  const onFrameButton3Click = useCallback(() => {
    navigate("/940-a-categories");
  }, [navigate]);

  return (
    <div className="self-stretch flex flex-col items-start justify-start gap-[46px] max-w-full text-left text-sm text-dimgray-200 font-inria-sans">
      <div className="w-[364px] flex flex-row items-start justify-center py-0 px-5 box-border max-w-full">
        <div className="w-[200px] flex flex-col items-start justify-start pt-[54px] px-8 pb-10 box-border relative gap-[17px]">
          <div className="w-full h-full absolute !m-[0] top-[0px] right-[0px] bottom-[0px] left-[0px] shadow-[0px_0px_23px_3px_rgba(73,_160,_120,_0.7)] rounded-[50%] bg-white" />
          <div className="flex flex-row items-start justify-start py-0 pr-[11px] pl-3">
            <b className="relative inline-block min-w-[113px] z-[1]">
              Your Total Balance
            </b>
          </div>
          <b className="relative text-13xl text-seagreen whitespace-nowrap z-[1]">
            $7,899.00
          </b>
          <div className="self-stretch flex flex-row items-start justify-start py-0 pr-11 pl-[45px]">
            <div className="h-[17px] flex-1 relative z-[1]">
              <div className="absolute top-[0px] left-[calc(50%_-_23.5px)] flex flex-row items-start justify-start gap-[6px] w-full h-full">
                <b className="relative inline-block min-w-[29px]">Hide</b>
                <div className="flex flex-col items-start justify-start pt-[3px] px-0 pb-0">
                  <img
                    className="w-3 h-3 relative"
                    loading="lazy"
                    alt=""
                    src="/vector.svg"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="self-stretch flex flex-row items-start justify-start gap-[230px] max-w-full text-white">
        <div className="w-[363px] flex flex-row items-start justify-start gap-[10.3px] shrink-0 [debug_commit:1de1738] max-w-full">
          <button
            className="cursor-pointer [border:none] pt-2.5 px-[5px] pb-[11px] bg-seagreen flex-[0.9733] rounded-8xs flex flex-row items-start justify-start gap-[8px]"
            onClick={onFrameButtonClick}
          >
            <div className="h-[41px] w-[83px] relative rounded-8xs bg-seagreen hidden" />
            <img
              className="h-5 w-5 relative rounded-31xl overflow-hidden shrink-0 z-[1]"
              loading="lazy"
              alt=""
              src="/sendplaneline.svg"
            />
            <div className="flex flex-col items-start justify-start pt-0.5 px-0 pb-0">
              <b className="relative text-xs inline-block font-inria-sans text-white text-left min-w-[25px] z-[1]">
                Sent
              </b>
            </div>
          </button>
          <button
            className="cursor-pointer [border:none] pt-3 px-[11px] pb-[15px] bg-paleturquoise flex-[0.8133] rounded-8xs flex flex-row items-start justify-end relative"
            onClick={onFrameButton1Click}
          >
            <div className="h-[41px] w-[83px] relative rounded-8xs bg-paleturquoise hidden z-[0]" />
            <b className="relative text-xs inline-block font-inria-sans text-white text-left min-w-[41px] z-[1]">
              Receive
            </b>
            <img
              className="h-[21.1px] w-[21.1px] absolute !m-[0] bottom-[9.9px] left-[5px] rounded-31xl overflow-hidden shrink-0 object-contain z-[1]"
              alt=""
              src="/sendplaneline-1@2x.png"
            />
          </button>
          <button
            className="cursor-pointer [border:none] pt-2.5 px-1 pb-[11px] bg-plum flex-1 rounded-8xs flex flex-row items-start justify-start gap-[8px]"
            onClick={onFrameButton2Click}
          >
            <div className="h-[41px] w-[83px] relative rounded-8xs bg-plum hidden" />
            <img
              className="h-5 w-5 relative min-h-[20px] z-[1]"
              alt=""
              src="/group-18.svg"
            />
            <div className="flex flex-col items-start justify-start pt-0.5 px-0 pb-0">
              <b className="relative text-xs font-inria-sans text-white text-left z-[1]">
                <p className="m-0">LOAN</p>
              </b>
            </div>
          </button>
          <button
            className="cursor-pointer [border:none] pt-[11px] px-[5px] pb-2.5 bg-black flex-[0.9733] rounded-8xs flex flex-row items-start justify-start gap-[8px]"
            onClick={onFrameButton3Click}
          >
            <div className="h-[41px] w-[83px] relative rounded-8xs bg-black hidden" />
            <img
              className="h-5 w-5 relative rounded-31xl overflow-hidden shrink-0 z-[1]"
              alt=""
              src="/addline1.svg"
            />
            <div className="flex flex-col items-start justify-start pt-px px-0 pb-0">
              <b className="relative text-xs inline-block font-inria-sans text-white text-left min-w-[28px] z-[1]">
                Swap
              </b>
            </div>
          </button>
        </div>
        <div className="w-[50px] flex flex-col items-start justify-start pt-[15px] px-0 pb-0 box-border shrink-0">
          <b className="self-stretch h-[13px] relative leading-[13px] inline-block shrink-0 [debug_commit:1de1738]">
            Deposit
          </b>
        </div>
      </div>
    </div>
  );
};

export default RecentTransactionsLabel1;
