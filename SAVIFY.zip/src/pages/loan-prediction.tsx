import { FunctionComponent, useCallback } from "react";
import FrameComponent8 from "../components/frame-component8";
import FrameComponent9 from "../components/frame-component9";
import { useNavigate } from "react-router-dom";

const LoanPrediction: FunctionComponent = () => {
  const navigate = useNavigate();

  const onHome3LineIconClick = useCallback(() => {
    navigate("/home");
  }, [navigate]);

  return (
    <div className="w-full relative rounded-21xl bg-main-green overflow-hidden flex flex-col items-end justify-start pt-[9px] px-0 pb-0 box-border gap-[53px] leading-[normal] tracking-[normal]">
      <header className="w-[376px] flex flex-row items-start justify-between py-0 pr-0 pl-5 box-border max-w-full gap-[20px] text-left text-smi text-white font-paragraph">
        <div className="relative capitalize font-medium inline-block min-w-[30px] whitespace-nowrap">
          16:04
        </div>
        <div className="flex flex-row items-end justify-start gap-[5px]">
          <div className="h-[11px] w-[33px] relative">
            <img
              className="absolute top-[0px] left-[0px] w-[13px] h-[11px]"
              loading="lazy"
              alt=""
              src="/vector1.svg"
            />
            <img
              className="absolute top-[2px] left-[18px] rounded-39xl w-[15px] h-2"
              alt=""
              src="/vector-12.svg"
            />
          </div>
          <img
            className="h-[9px] w-[17px] relative"
            loading="lazy"
            alt=""
            src="/group-12.svg"
          />
        </div>
      </header>
      <section className="self-stretch flex flex-row items-start justify-end pt-0 pb-[55px] pr-[19px] pl-[22px] box-border max-w-full text-center text-11xl text-letters-and-icons font-subtitle">
        <div className="flex-1 flex flex-row items-end justify-between max-w-full gap-[20px]">
          <div className="flex flex-col items-start justify-end pt-0 pb-1.5 pr-2.5 pl-0">
            <img
              className="w-[19px] h-4 relative"
              loading="lazy"
              alt=""
              src="/bring-back.svg"
            />
          </div>
          <h1 className="m-0 relative text-inherit leading-[22px] capitalize font-semibold font-inherit inline-block min-w-[81px]">
            LOAN
          </h1>
          <img
            className="h-[30px] w-[30px] relative rounded-[25.71px] overflow-hidden shrink-0"
            loading="lazy"
            alt=""
            src="/iconnotification.svg"
          />
        </div>
      </section>
      <FrameComponent8 />
      <FrameComponent9 />
      <section className="self-stretch flex flex-row items-start justify-center pt-0 pb-[57px] pr-8 pl-5 text-center text-xl text-letters-and-icons font-subtitle">
        <div className="h-[45px] w-[207px] relative z-[1]">
          <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%]">
            <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-11xl bg-main-green" />
          </div>
          <div className="absolute top-[24.44%] left-[calc(50%_-_110.5px)] leading-[22px] capitalize font-semibold flex items-center justify-center w-[220px] z-[1]">
            PREDICT
          </div>
        </div>
      </section>
      <section className="self-stretch h-[87px] flex flex-col items-start justify-start py-0 pr-0 pl-px box-border max-w-full">
        <footer className="self-stretch shadow-[1px_0px_8px_rgba(0,_0,_0,_0.25)] rounded-t-11xl rounded-b-none bg-white flex flex-row items-start justify-start pt-[31px] px-[39px] pb-[30px] box-border relative gap-[67px] shrink-0 [debug_commit:1de1738] max-w-full z-[1]">
          <div className="h-[87px] w-[393px] relative shadow-[1px_0px_8px_rgba(0,_0,_0,_0.25)] rounded-t-11xl rounded-b-none bg-white hidden max-w-full z-[0]" />
          <img
            className="h-[26px] w-[26px] relative overflow-hidden shrink-0 min-h-[26px] cursor-pointer z-[2]"
            loading="lazy"
            alt=""
            src="/home3line2.svg"
            onClick={onHome3LineIconClick}
          />
          <img
            className="h-[26px] w-[26px] relative overflow-hidden shrink-0 min-h-[26px] z-[2]"
            loading="lazy"
            alt=""
            src="/refundline2.svg"
          />
          <img
            className="h-[26px] w-[26px] relative overflow-hidden shrink-0 min-h-[26px] z-[2]"
            loading="lazy"
            alt=""
            src="/barchartgroupedline1.svg"
          />
          <img
            className="h-[26px] w-[26px] absolute !m-[0] right-[48px] bottom-[30px] overflow-hidden shrink-0 z-[2]"
            loading="lazy"
            alt=""
            src="/settings2line1.svg"
          />
        </footer>
        <div className="ml-[-19px] w-[430px] h-[745px] relative shrink-0 [debug_commit:1de1738] max-w-[110%] flex items-center justify-center">
          <img
            className="w-full h-full shrink-0 [debug_commit:1de1738] object-contain absolute left-[0px] top-[293px] [transform:scale(8.313)]"
            alt=""
            src="/base-shape1.svg"
          />
        </div>
      </section>
    </div>
  );
};

export default LoanPrediction;
