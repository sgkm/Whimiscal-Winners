import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const AOnBoarding: FunctionComponent = () => {
  const navigate = useNavigate();

  const onNextIconClick = useCallback(() => {
    navigate("/2-b-on-boarding");
  }, [navigate]);

  return (
    <div className="w-full relative rounded-xl bg-main-green overflow-hidden flex flex-col items-end justify-start pt-[123px] px-[52px] pb-[72px] box-border gap-[241.5px] leading-[normal] tracking-[normal] text-center text-11xl text-dark-mode-green-bar font-subtitle">
      <div className="relative leading-[39px] capitalize font-semibold">
        Welcome to Savify
      </div>
      <section className="w-full h-[544px] absolute !m-[0] right-[0px] bottom-[0px] left-[0px]">
        <img
          className="absolute top-[0px] left-[-17px] w-[430px] h-[624px]"
          alt=""
          src="/base-shape.svg"
        />
        <div className="absolute top-[135px] left-[99px] rounded-[50%] bg-light-green w-[248px] h-[248px] z-[1]" />
        <img
          className="absolute top-[499px] left-[194px] w-[42px] h-[13px] cursor-pointer z-[1]"
          loading="lazy"
          alt=""
          src="/next.svg"
          onClick={onNextIconClick}
        />
      </section>
      <section className="self-stretch flex flex-col items-start justify-start gap-[67.5px] text-center text-11xl text-dark-mode-green-bar font-subtitle">
        <img
          className="w-[287px] h-[287px] relative object-cover z-[2]"
          loading="lazy"
          alt=""
          src="/ilustracion3dmanodineroblancoremovebgpreview-1@2x.png"
        />
        <div className="self-stretch flex flex-row items-start justify-center py-0 px-5">
          <div className="relative leading-[22px] capitalize font-semibold inline-block min-w-[69px] z-[1]">
            Next
          </div>
        </div>
      </section>
    </div>
  );
};

export default AOnBoarding;
