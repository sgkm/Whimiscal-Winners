import { FunctionComponent } from "react";

const SecurityPinInput: FunctionComponent = () => {
  return (
    <section className="w-[320.2px] flex flex-row items-start justify-start pt-0 px-1.5 pb-[10.7px] box-border max-w-full text-center text-xl text-dark-mode-green-bar font-subtitle">
      <div className="flex-1 flex flex-col items-start justify-start gap-[68px]">
        <div className="flex flex-row items-start justify-start py-0 px-[66px]">
          <h3 className="m-0 relative text-inherit leading-[22px] capitalize font-semibold font-inherit z-[1]">
            Enter security pin
          </h3>
        </div>
        <div className="self-stretch flex flex-row items-start justify-start gap-[14.5px] text-mid-1">
          <div className="h-[39.3px] flex-1 relative">
            <div className="absolute top-[0px] left-[0px] rounded-[50%] box-border w-full h-full z-[1] border-[0px] border-solid border-main-green" />
            <div className="absolute top-[10.2px] left-[14.5px] leading-[19px] capitalize font-semibold inline-block min-w-[10px] z-[2]">
              2
            </div>
          </div>
          <div className="h-[39.3px] flex-1 relative">
            <div className="absolute top-[0px] left-[0px] rounded-[50%] box-border w-full h-full z-[1] border-[0px] border-solid border-main-green" />
            <div className="absolute top-[10.2px] left-[14.5px] leading-[19px] capitalize font-semibold inline-block min-w-[10px] z-[2]">
              7
            </div>
          </div>
          <div className="h-[39.3px] flex-1 relative">
            <div className="absolute top-[0px] left-[0px] rounded-[50%] box-border w-full h-full z-[1] border-[0px] border-solid border-main-green" />
            <div className="absolute top-[10.2px] left-[14.5px] leading-[19px] capitalize font-semibold inline-block min-w-[11px] z-[2]">
              3
            </div>
          </div>
          <div className="h-[39.3px] flex-1 relative">
            <div className="absolute top-[0px] left-[0px] rounded-[50%] box-border w-full h-full z-[1] border-[0px] border-solid border-main-green" />
            <div className="absolute top-[10.2px] left-[14.6px] leading-[19px] capitalize font-semibold inline-block min-w-[11px] z-[2]">
              9
            </div>
          </div>
          <div className="h-[39.3px] flex-1 relative">
            <div className="absolute top-[0px] left-[0px] rounded-[50%] box-border w-full h-full z-[1] border-[0px] border-solid border-main-green" />
            <div className="absolute top-[10.2px] left-[16.5px] leading-[19px] capitalize font-semibold inline-block min-w-[7px] z-[2]">
              1
            </div>
          </div>
          <div className="h-[39.3px] flex-1 relative">
            <div className="absolute top-[0px] left-[0px] rounded-[50%] box-border w-full h-full z-[1] border-[0px] border-solid border-main-green" />
            <div className="absolute top-[10.2px] left-[14.5px] leading-[19px] capitalize font-semibold inline-block min-w-[11px] z-[2]">
              6
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SecurityPinInput;
