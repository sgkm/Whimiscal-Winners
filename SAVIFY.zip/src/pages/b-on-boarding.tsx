import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const BOnBoarding: FunctionComponent = () => {
  const navigate = useNavigate();

  const onNextTextClick = useCallback(() => {
    navigate("/finance-app");
  }, [navigate]);

  return (
    <div className="w-full relative rounded-xl bg-main-green overflow-hidden flex flex-col items-end justify-start pt-[123px] px-[52px] pb-[72px] box-border gap-[163px] leading-[normal] tracking-[normal]">
      <section className="w-full h-[544px] absolute !m-[0] right-[0px] bottom-[0px] left-[0px]">
        <img
          className="absolute top-[0px] left-[-17px] w-[430px] h-[624px]"
          alt=""
          src="/base-shape.svg"
        />
        <img
          className="absolute top-[499px] left-[194px] w-[42px] h-[13px] z-[1]"
          loading="lazy"
          alt=""
          src="/next1.svg"
        />
        <div className="absolute top-[135px] left-[99px] rounded-[50%] bg-light-green w-[248px] h-[248px] z-[1]" />
      </section>
      <section className="self-stretch relative text-11xl leading-[39px] capitalize font-semibold font-subtitle text-dark-mode-green-bar text-center">
        ¿Are you ready to take control of your finaces?
      </section>
      <section className="self-stretch flex flex-col items-start justify-start gap-[68px] text-center text-11xl text-dark-mode-green-bar font-subtitle">
        <img
          className="w-[287px] h-[287px] relative object-cover z-[2]"
          loading="lazy"
          alt=""
          src="/bankcardmobilephoneonlinepaymentremovebgpreview-1@2x.png"
        />
        <div className="self-stretch flex flex-row items-start justify-center py-0 px-5">
          <div
            className="relative leading-[22px] capitalize font-semibold inline-block min-w-[69px] cursor-pointer z-[1]"
            onClick={onNextTextClick}
          >
            Next
          </div>
        </div>
      </section>
    </div>
  );
};

export default BOnBoarding;
