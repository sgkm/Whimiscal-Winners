import { FunctionComponent, useCallback } from "react";
import RecentTransactionsLabel1 from "../components/recent-transactions-label1";
import FrameComponent1 from "../components/frame-component1";
import { useNavigate } from "react-router-dom";

const Home: FunctionComponent = () => {
  const navigate = useNavigate();

  const onRefundLineIconClick = useCallback(() => {
    navigate("/add-card");
  }, [navigate]);

  const onBarChartGroupedLineIconClick = useCallback(() => {
    navigate("/analytics");
  }, [navigate]);

  const onSettings2LineIconClick = useCallback(() => {
    navigate("/profile");
  }, [navigate]);

  return (
    <div className="w-full h-[852px] relative rounded-xl bg-white overflow-hidden leading-[normal] tracking-[normal] text-left text-3xl text-black font-inria-sans">
      <img
        className="absolute top-[87px] left-[360px] w-[18px] h-[22px] overflow-hidden"
        loading="lazy"
        alt=""
        src="/notificationline.svg"
      />
      <div className="absolute top-[72px] left-[15px] w-[350px] flex flex-row items-start justify-start gap-[7px]">
        <img
          className="h-[50px] w-[50px] relative rounded-31xl overflow-hidden shrink-0"
          loading="lazy"
          alt=""
          src="/userfill-1.svg"
        />
        <div className="flex-1 flex flex-col items-start justify-start pt-1 px-0 pb-0">
          <div className="flex flex-col items-start justify-start py-0 pr-5 pl-0 gap-[3px]">
            <h2 className="m-0 relative text-inherit font-bold font-inherit inline-block min-w-[61px]">
              KRISH
            </h2>
            <div className="relative text-2xs font-light text-dimgray-100 inline-block min-w-[70px]">
              Good Morning!
            </div>
          </div>
        </div>
        <div className="flex flex-col items-start justify-start pt-3 px-0 pb-0 text-8xs text-white">
          <div className="flex flex-row items-start justify-start py-0 pr-1 pl-0">
            <div className="h-2.5 w-2.5 relative rounded-[50%] bg-crimson box-border z-[1] border-[0px] border-solid border-gray-100" />
            <div className="flex flex-col items-start justify-start pt-0.5 px-0 pb-0 ml-[-6px]">
              <b className="relative inline-block min-w-[2px] z-[2]">1</b>
            </div>
          </div>
        </div>
      </div>
      <section className="absolute top-[173px] left-[15px] w-[378px] flex flex-col items-start justify-start gap-[49px] max-w-full text-left text-3xl text-black font-kontora">
        <RecentTransactionsLabel1 />
        <h2 className="m-0 h-[22px] relative text-inherit font-extrabold font-inherit inline-block">
          Recent Transaction
        </h2>
      </section>
      <FrameComponent1 />
      <div className="absolute top-[764px] left-[80px] text-xs text-darkgray-200 hidden min-w-[125px] whitespace-nowrap">
        20 Jan 2024 at 10:00 PM
      </div>
      <section className="absolute top-[765px] left-[0px] shadow-[1px_0px_8px_rgba(0,_0,_0,_0.25)] rounded-t-11xl rounded-b-none bg-white w-[393px] flex flex-row items-start justify-start pt-8 px-[41px] pb-[29px] box-border gap-[67px] max-w-full z-[1]">
        <div className="h-[87px] w-[393px] relative shadow-[1px_0px_8px_rgba(0,_0,_0,_0.25)] rounded-t-11xl rounded-b-none bg-white hidden max-w-full z-[0]" />
        <img
          className="h-[26px] w-[26px] relative overflow-hidden shrink-0 min-h-[26px] z-[2]"
          loading="lazy"
          alt=""
          src="/home3line2.svg"
        />
        <img
          className="h-[26px] w-[26px] relative overflow-hidden shrink-0 min-h-[26px] cursor-pointer z-[2]"
          loading="lazy"
          alt=""
          src="/refundline2.svg"
          onClick={onRefundLineIconClick}
        />
        <img
          className="h-[26px] w-[26px] relative overflow-hidden shrink-0 min-h-[26px] cursor-pointer z-[2]"
          loading="lazy"
          alt=""
          src="/barchartgroupedline1.svg"
          onClick={onBarChartGroupedLineIconClick}
        />
        <img
          className="h-[26px] w-[26px] absolute !m-[0] right-[47px] bottom-[29px] overflow-hidden shrink-0 cursor-pointer z-[2]"
          loading="lazy"
          alt=""
          src="/settings2line1.svg"
          onClick={onSettings2LineIconClick}
        />
      </section>
    </div>
  );
};

export default Home;
