import { FunctionComponent } from "react";
import RecentTransactionsLabel from "./recent-transactions-label";

const FrameComponent1: FunctionComponent = () => {
  return (
    <section className="absolute top-[569px] left-[15px] w-[363px] h-[215px] flex flex-row items-start justify-between gap-[20px] text-left text-lg text-black font-inria-sans">
      <div className="self-stretch w-[190px] flex flex-col items-start justify-start gap-[35px]">
        <RecentTransactionsLabel />
        <div className="h-[50px] flex flex-row items-start justify-start py-0 px-px box-border">
          <div className="self-stretch flex flex-row items-start justify-start gap-[14px]">
            <div className="h-[50px] w-[50px] relative rounded-31xl shrink-0 flex items-center justify-center">
              <img
                className="h-full w-full overflow-hidden shrink-0 object-contain absolute left-[0px] top-[0px] [transform:scale(1.48)]"
                loading="lazy"
                alt=""
                src="/arrowrightupline-1.svg"
              />
            </div>
            <div className="flex flex-col items-start justify-start pt-[5px] px-0 pb-0">
              <h3 className="m-0 relative text-inherit font-bold font-inherit inline-block min-w-[98px]">{`To Delhivery `}</h3>
            </div>
          </div>
        </div>
      </div>
      <div className="flex flex-col items-start justify-start pt-3.5 px-0 pb-0">
        <div className="flex flex-col items-start justify-start gap-[55px]">
          <b className="relative inline-block min-w-[88px]">+$3,456.00</b>
          <div className="flex flex-row items-start justify-start pt-0 pb-[11px] pr-0 pl-1.5 text-right">
            <b className="relative inline-block min-w-[82px]">-$1,396.00</b>
          </div>
          <div className="flex flex-row items-start justify-start py-0 pr-[3px] pl-[11px]">
            <b className="relative inline-block min-w-[74px]">-$500.00</b>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FrameComponent1;
