import { FunctionComponent } from "react";
import SecurityPinInput from "../components/security-pin-input";
import FrameComponent2 from "../components/frame-component2";
import SignUpLink from "../components/sign-up-link";

const ASecurityPin: FunctionComponent = () => {
  return (
    <div className="w-full relative rounded-xl bg-main-green overflow-hidden flex flex-col items-start justify-start pt-[9px] pb-[15px] pr-0 pl-[37px] box-border gap-[77px] leading-[normal] tracking-[normal]">
      <img
        className="w-[430px] h-[745px] absolute !m-[0] right-[-20px] bottom-[-80px]"
        alt=""
        src="/base-shape1.svg"
      />
      <header className="self-stretch flex flex-row items-start justify-between gap-[20px] text-left text-smi text-white font-paragraph">
        <div className="relative capitalize font-medium inline-block min-w-[30px] whitespace-nowrap">
          16:04
        </div>
        <div className="flex flex-row items-end justify-start gap-[5px]">
          <div className="h-[11px] w-[33px] relative">
            <img
              className="absolute top-[0px] left-[0px] w-[13px] h-[11px]"
              loading="lazy"
              alt=""
              src="/vector1.svg"
            />
            <img
              className="absolute top-[2px] left-[18px] rounded-39xl w-[15px] h-2"
              alt=""
              src="/vector-12.svg"
            />
          </div>
          <img
            className="h-[9px] w-[17px] relative"
            loading="lazy"
            alt=""
            src="/group-12.svg"
          />
        </div>
      </header>
      <section className="flex flex-row items-start justify-start pt-0 px-[71px] pb-[78px] box-border max-w-full text-center text-11xl text-letters-and-icons font-subtitle">
        <h1 className="m-0 relative text-inherit leading-[22px] capitalize font-semibold font-inherit">
          Security pin
        </h1>
      </section>
      <SecurityPinInput />
      <FrameComponent2 />
      <SignUpLink />
    </div>
  );
};

export default ASecurityPin;
