import { FunctionComponent } from "react";

const FrameComponent3: FunctionComponent = () => {
  return (
    <div className="self-stretch rounded-sm bg-honeydew overflow-hidden flex flex-col items-center justify-start pt-[11px] px-5 pb-[5px] box-border max-w-full text-left text-mini text-letters-and-icons font-subtitle">
      <div className="w-[357px] h-[75px] relative rounded-sm bg-honeydew hidden max-w-full" />
      <div className="flex flex-row items-start justify-start py-0 pr-2 pl-[9px]">
        <div className="relative capitalize font-medium inline-block min-w-[104px] z-[1]">
          Total Balance
        </div>
      </div>
      <b className="relative text-5xl capitalize inline-block min-w-[117px] whitespace-nowrap z-[1]">
        $7,783.00
      </b>
    </div>
  );
};

export default FrameComponent3;
